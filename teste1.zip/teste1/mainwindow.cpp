#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cstring>
#include <iostream>
#include <fstream>

ifstream arq("D140193-2022-10-30.csv");



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
string
float medium;
void MainWindow::on_BTNmedium_value_clicked()
{
    medium = 2;
}

