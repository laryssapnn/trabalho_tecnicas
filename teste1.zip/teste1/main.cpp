#include "mainwindow.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>


#include <QApplication>
using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();


    ifstream ip("D140193-2022-10-30.csv");

    if(!ip.is_open()){cout << "Arquivo não encontrado!" << endl;}
}
